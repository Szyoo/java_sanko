package extra;

public class Constant {
    
}
