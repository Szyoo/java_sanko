package enhancement;

public class Constant {
    
}
