package jp.co.sss.crud.util;

public class Constant {
    /** 性別の初期値 */
    public static final Integer DEFAULT_GENDER = 0;

    /** 権限の初期値 */
    public static final Integer DEFAULT_AUTHORITY = 0;

    /** 部署IDの初期値 */
    public static final Integer DEFAULT_DEPT_ID = 0;
}
