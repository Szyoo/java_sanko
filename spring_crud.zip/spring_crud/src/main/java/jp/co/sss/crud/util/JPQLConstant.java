package jp.co.sss.crud.util;

/**
 * 独自JPQLを定義するためのクラス
 *
 * @author System Shared
 */
public class JPQLConstant {
    /** 社員情報の全件検索(社員ID順) */
    // ここに追記

    /** 社員情報の社員名検索(社員ID順) */
    // ここに追記

    /** 社員情報の部署ID検索(社員ID順) */
    // ここに追記
}
