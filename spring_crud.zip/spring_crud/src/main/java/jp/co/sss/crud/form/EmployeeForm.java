package jp.co.sss.crud.form;

public class EmployeeForm {
    
}
