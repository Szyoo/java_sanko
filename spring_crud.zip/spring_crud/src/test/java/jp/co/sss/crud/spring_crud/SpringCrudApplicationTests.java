package jp.co.sss.crud.spring_crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import jp.co.sss.crud.SpringCrudApplication;

@SpringBootApplication
class SpringCrudApplicationTests {

	public static void main(String[] args) {
		SpringApplication.run(SpringCrudApplication.class, args);
	}

}
